var searchData=
[
  ['char_5fspacing_5fdefault',['CHAR_SPACING_DEFAULT',['../_m_d___m_a_x_panel__lib_8h.html#a804ff741ca21eab5b927d6dde890e3ca',1,'MD_MAXPanel_lib.h']]]
];
