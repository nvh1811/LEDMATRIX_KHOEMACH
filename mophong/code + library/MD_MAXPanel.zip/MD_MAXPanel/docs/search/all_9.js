var searchData=
[
  ['update',['update',['../class_m_d___m_a_x_panel.html#abcaac4635c9e377c7fe57d072589e752',1,'MD_MAXPanel::update(bool state)'],['../class_m_d___m_a_x_panel.html#a592a252dfe9db3488b98737bfb959a91',1,'MD_MAXPanel::update()']]]
];
