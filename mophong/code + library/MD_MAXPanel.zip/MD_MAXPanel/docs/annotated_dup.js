var annotated_dup =
[
    [ "MD_MAXPanel", "class_m_d___m_a_x_panel.html", "class_m_d___m_a_x_panel" ]
];